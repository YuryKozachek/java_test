package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int a = 5;
        int b = 3;
        int c = a * b;
        System.out.println(c + " Ответ");

    }
}
